/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 */
import java.util.*;
public class Booking implements BookingManagement {
    /**
     * these attributes are used to make booking for customer
     */
    private Customer customer;
    private Stylist stylist;
    protected ArrayList<Service> allService;
    private Date date ;
    private Time time;
    private double price;
    private Receipt receipt;
    private Review review;
    /**
     * this constructor is used to declare the objects and the price
     */
    public Booking() {
        allService = new ArrayList<>();
        customer=new Customer();
        stylist= new Stylist();
        date= new Date();
        time=new Time();
        receipt = new Receipt();
        review=new Review();
        this.price=0.0;
    }
    /**
     * this constructor is used in main class
     * @param customer
     * @param stylist
     * @param date
     * @param time 
     */
    public Booking(Customer customer, Stylist stylist, Date date, Time time) {
        allService = new ArrayList<>();
        this.customer = customer;
        this.stylist = stylist;
        this.date = date;
        this.time = time;
    }
    /**
   * this method is used to return the price
   * @return double
   */    public double getPrice() {
        return price;
    }
    /**
   * this method is used to return the customer
   * @return customer
   */
    public Customer getCustomer() {
        return customer;
    }
    /**
    * this method for setting the Customer.
    * @param c
    */
    public void setCustomer(Customer c) {
        this.customer = c;
    }
    /**
   * this method is used to return the Stylist
   * @return Stylist
   */
      public Stylist getStylist() {
        return stylist;
    }
      /**
    * this method for setting the Stylist.
    * @param s 
    */
    public void setStylist(Stylist s) {
        this.stylist = s;
    }
    /**
   * this method is use to return the date
   * @return date
   */
    public Date getDate() {
        return date;
    }
    /**
    * this method for setting the date.
    * @param date 
    */
    public void setDate(Date date) {
        this.date = date; 
    }
     /**
   * this method is use to return the time
   * @return time
   */
    public Time getTime() {
        return time;
    }
    /**
    * this method for setting the time.
    * @param time 
    */
    public void setTime(Time time) {
        this.time = time;
    }
    /**
   * this method is use to return the receipt
   * @return receipt
   */
    public Receipt getReceipt() {
        return receipt;
    }
    /**
    * this method for setting the receipt.
    * @param receipt 
    */
    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }
    /**
      * this method is use to return the review
      * @return review
      */
    public Review getReview() {
        return review;
    }
    /**
    * this method for setting the review
    * @param review 
    */
    public void setReview(Review review) {
        this.review = review;
    }
    /**
    * this method is used to create receipt and pass the price to it
    * @return Receipt
    */
    public Receipt createReceipt(){
        this.calculatePrice();
        this.receipt=new Receipt(price);
        return this.receipt;
    }
    /**
     * this method is used to add service
     * @param s 
     */
    public void addService(Service s){
        allService.add(s);
    }
    /**
     * this method is used to delete service
     * @param s 
     */
    public void deleteService(Service s){
        allService.remove(s);
    }

    /**
     * this method is used to display all existing services
     */
    public void displayService(){
        for (int i=0; i<allService.size();i++) {
            Service ser=allService.get(i);
            System.out.println(ser);
            Stylist st=allService.get(i).getStylist();
            System.out.println(st);
        }
        System.out.println( createReceipt());
    }
    /**
     * this method is used to update the date of reservation
     * @param d 
     */
    public void updateDate(Date d){
        for (int i = 0; i <allService.size(); i++) {
            if(allService.get(i).getDate().equals(d))
            allService.get(i).setDate(d);
        } 
    }
    /**
     * this method is used to update the time of reservation
     * @param t 
     */
    public void updateTime(Time t){
        for (int i = 0; i <allService.size(); i++) {
            if(allService.get(i).getTime().equals(t)){
                allService.get(i).setTime(t);
            }
        }  
    }
    /**
     * this method is used to check Availability for each date and time
     * @param d
     * @param t
     * @return boolean
     */
    public boolean checkAvailability(Date d, Time t){
        if(this.date.equals(d)&&this.time.equals(t)){
            return false;
        }else{
            return true;
        }
    }
    /**
     * this method is used to calculate Price for each service in the booking
     */
    @Override
    public void calculatePrice() {
        double total=0;
        for (int i=0; i<allService.size();i++) {
            Service ser=allService.get(i);
            total+=ser.getPrice();
        }
        this.price=total;
    }
    /**
     * this method is used to display the booking elements as string
     * @return String
     */
    @Override
    public String toString() {
    return "Booking:\nCustomer info:\n" + customer +"\nDate and time:\n" + date + "\t" + time ;
    }
}