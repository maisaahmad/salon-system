/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 * this is the super class of stylist and customer
 */
public class Person {
    /**
     * this attribute is used to identify the name & phone number of the person(customer,stylist)
     */
    private String name;
    private String  phoneNumber="";
    
    /**
     * we create the constructor because we need the argument constructor 
     */
    public Person() {}
   /**
    * in this constructor we  hold the value in object
    * @param n
    * @param pn 
    */
    public Person(String n, String pn) {
        this.name = n;
         /**
         * we add this condition to make sure the user input correct value
         */
        if(pn.length()==10){
         this.phoneNumber = pn; 
        }else{System.out.println("invalid phone Number :(");}
       
    }
    /**
   * this method is use to return the name
   * @return String
   */
    public String getName() {
        return name;
    }
    /**
    * this method for setting the name.
    * @param n 
    */
    public void setName(String n) {
        this.name = n;
    }
     /**
   * this method is use to return the phone Number
   * @return String
   */
    public String getPhoneNumber() {
        return phoneNumber;
    }
    /**
    * this method for setting the phone Number.
    * @param  phoneNumber
    */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    /**
     * to display the name and the phone number of person (customer,stylist)
     * @return String
     */
    @Override
    public String toString() {
        return "Name: " + name + "\nPhone Number:  " + phoneNumber;
    }
    /**
  * this method is used for compare the number and name of the the stylist
  * @param obj
  * @return boolean 
  */
    @Override
    public boolean equals(Object obj) {
        Person c =(Person)obj;
        if (c.getName().equalsIgnoreCase(this.name)&&c.getPhoneNumber().equals(this.phoneNumber)){
            return true;
        } else {
            return false;
        }
    }
}