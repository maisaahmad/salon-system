/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;


/**
 *
 * @author huawei
 * this class contains the info of stylist
 */
public class Stylist extends Person {
    /**
     * this attributes is used to identify the stylist 
     */
    private String id;
    /**
     * this attributes is used to identify the job of stylist 
     */
    private Service job;
    /**
     * we create the constructor because we need the argument constructor 
     */
    public Stylist() {}
    /**
     * we create the constructor because we need the argument constructor in the main
     * @param n
     * @param pn
     * @param id
     * @param job
     */
    public Stylist(String n,String pn,String id,Service job){
        super(n,pn);
        this.id = id;
        this.job = job;
    }
    /**
   * this method is use to return the id
   * @return String
   */
    public String getId() {
        return id;
    }
    /**
    * this method for setting the id.
    * @param id 
    */
    public void setId(String id) {
        this.id = id;
    }
    /**
   * this method is use to return the job
   * @return Service
   */
    public Service getJob() {
        return job;
    }
     /**
    * this method for setting the job.
    * @param job 
    */
    public void setJob(Service job) {
        this.job = job;
    }
     /**
     * to display the name ,phone number ,id and job of stylist as string
     * @return String
     */
    public String toString() {
        
        return "Name: " + super.getName() + "\nPhone Number: " + super.getPhoneNumber()+"\nID: " + id ;
        }
}