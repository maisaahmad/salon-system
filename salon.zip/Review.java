/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;


/**
 *
 * @author huawei
 * this class is used to show the review about the stylist and the salon in general
 */
public class Review {
   /**
    * this attribute is used to evaluate the service if it is good or not
    */
    private boolean evaluation;
    /**
     * this attribute is used to allow customer to add note
     */
    private String notes;
    /**
     * this attribute is used to know which customer add the note
     */
    private Customer customer;
    /**
     * this attribute is used to add the review to the selected stylist
     */
    private Stylist stylist;
    /**
     * this constructor is used to create the array
     */
    public Review() {}
   /**
    *this constructor is used to  because we need the argument constructor in the main
    * @param evaluation
    * @param notes
    * @param customer
    * @param stylist 
    */
    public Review(boolean evaluation, String notes, Customer customer, Stylist stylist) {
        this.evaluation = evaluation;
        this.notes = notes;
        this.customer = customer;
        this.stylist = stylist;
    }
   /**
   * this method is use to return the evaluation
   * @return boolean
   */
    public boolean isEvaluation() {
        return evaluation;
    }
    /**
    * this method for setting the evaluation.
    * @param evaluation 
    */
    public void setEvaluation(boolean evaluation) {
        this.evaluation = evaluation;
    }
    /**
   * this method is use to return the Customer
   * @return Customer
   */
    public Customer getCustomer() {
        return customer;
    }
     /**
    * this method for setting the customer.
    * @param customer 
    */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    /**
   * this method is use to return the stylist
   * @return Stylist
   */
    public Stylist getStylist() {
        return stylist;
    }
    /**
    * this method for setting the stylist.
    * @param stylist 
    */
    public void setStylist(Stylist stylist) {
        this.stylist = stylist;
    }
     /**
   * this method is use to return the notes
   * @return notes
   */
    public String getNotes() {
        return notes;
    }
    /**
    * this method for setting the notes.
    * @param notes 
    */
    public void setNotes(String notes) {
        this.notes = notes;
    }
    /**
     * this method is used to display all the in info of the review
     * @return 
     */
    @Override
    public String toString() {
        String rate=new String();
        if (evaluation){
            rate="Liked the service";
        }else{
            rate="Did not like the service";
        }
        return "Review\nStylist:" + stylist+"\nEvaluation: "+rate+"\nNotes: "+notes;
    }
}