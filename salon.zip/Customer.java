/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 * this class contains the info of customer
 */
public class Customer extends Person {
 /**
  * this attribute  is used to identify the  Credit Card Number of customer 
  */
    private String CreditCardNo;
   
    /**
     * we create the constructor because we need the argument constructor 
     */
    public Customer() {
    }
     /**
     * we create the constructor because we need the argument constructor 
     * @param n
     * @param pn
     * @param CreditCardNo
     */
    public Customer(String n, String pn, String CreditCardNo) {
        super(n,pn);
        /**
         * we add this condition to make sure the user input correct value
         */
        if(CreditCardNo.length()==16){
          this.CreditCardNo= CreditCardNo;  
        }else{System.out.println("invalid Credit Card Number :(");}
       
    }
    /**
   * this method is use to return the CreditCardNo
   * and change the number to stars for privacy
   * @return String
   */
    public String getCreditCardNo() {
        String c="**** **** **** "+CreditCardNo.substring(12);
        return c;
    }
     /**
    * this method for setting the CreditCardNo.
    * @param CreditCardNo 
    */
    public void setCreditCardNo(String CreditCardNo) {
        this.CreditCardNo = CreditCardNo;
    }

  /**
     * to display the name and phone number of Customer
     * @return String
     */
    @Override
    public String toString() {
        return super.toString();
    }
    
}