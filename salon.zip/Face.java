/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 * this class is for face services
 * @author huawei
 */
public class Face extends Service {
    //attributes
    private String makeupColor;
    private int makeupType;
    private boolean skinCare;
    //constructors
    public Face(){}
    public Face(int makeupType, String makeupColor) {
        this.makeupType = makeupType;
        this.makeupColor = makeupColor;
    }
    public Face(Date date,Time time,Stylist stylist,int makeupType, String makeupColor) {
        super(date,time,stylist);
        this.makeupType = makeupType;
        this.makeupColor = makeupColor;
    }
    //methods
    public boolean isSkinCare() {
        return skinCare;
    }
    public void setSkinCare(boolean skinCare) {
        this.skinCare = skinCare;
    }
    public int getMakeupType() {
        return makeupType;
    }
    public void setMakeupType(int makeupType) {
        switch(makeupType){
            case 1://special
                super.setPrice(200);
                break;
            case 2://normal
                super.setPrice(150);
                break;
            case 3://bride
                super.setPrice(300);
                break;
            default://neither
                System.out.println("Invalid input");
        }
    }
    public String getMakeupColor() {
        return makeupColor;
    }
    public void setMakeupColor(String makeupColor) {
        this.makeupColor = makeupColor;
    }
    @Override
    public void calculatePrice() {
        if(skinCare){
            super.setPrice(getPrice()+50);
        }else{
            super.setPrice(getPrice());
        }
    }
    @Override
    public String toString() {
       
       String t=new String();
       if (makeupType==1)
            t="Special";
       else if (makeupType==2)
            t="Normal";
       else
            t="Bride";
       return "Face Service\nMakeup Type: " + t + "\nMakeup Color: " + makeupColor+"\nSkincare: "+skinCare+"\nPrice: "+getPrice();
    }
}