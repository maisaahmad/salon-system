/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 */
public class Time {
    /**
     * these attributes for reservation time and local time of receipt
  */
  private int second;
  private int minute;
  private int hours;
    /**
     * we create the constructor because we need the argument constructor 
     */
    public Time() {}
    
    /**
     * we create this constructor to hold the value in object for  reservation time.we add this condition to make sure the user i/p the correct time
     * @param hours
     * @param minute
     */
    public Time(int hours, int minute) {
         if(hours>=10&&hours<=22&&minute<=60&&minute>=0){
        this.minute = minute;
        this.hours = hours;}
         else{
        System.err.println("Out of work time!");}
    }
    /**
     * we create this constructor to make an object for  receipt time 
     * @param hours
     * @param minute
     * @param second
     */
      public Time(int hours, int minute, int second) {    
        this.second = second;
        this.minute = minute;
        this.hours = hours;
    }
  /**
   * this method is use to return the seconds
   * @return int
   */
    public int getSecond() {
        return second;
    }
   /**
    * this method for setting the seconds.
    * @param second 
    */
    public void setSecond(int second) {
        this.second = second;
    }

  /**
   * this method is use to return the minutes
   * @return int
   */
    public int getMinute() {
        return minute;
    }
    /**
    * this method for setting the minute.we add this condition to make sure the user i/p the correct minute
    * @param minute 
    */
    public void setMinute(int minute) {
        if(minute<=60&&minute>=0)
        this.minute = minute;
    }
    /**
   * this method is use to return the hours
   * @return int
   */
    public int getHours() {
        return hours;
    }
    /**
    * this method for setting the hours.we add this condition to make sure the user i/p the correct hours
    * @param hours 
    */
    public void setHours(int hours) {
        if(hours<=10&&hours>=22)
        this.hours = hours;
    }
    /**
     * we used this method to check if our conditions on date were applied 
     * we used it in the main class as a loop condition to let user try again
     * @return 
     */
     public boolean check(){
        if(hours>=10&&hours<=22&&minute<=60&&minute>=0){
            return true;}
        else{
            return false;}
        }
 /**
  * this method is used for (checkAvailability) method in class booking
  * @param obj
  * @returnboolean 
  */
    @Override
  public boolean equals(Object obj){
        Time t=(Time)obj;
        if (t.hours==this.hours && t.minute==this.minute)
            return true;
        else
            return false;
    }
 /**
  * this method is used to display the time
  * @return String
  */
    @Override
    public String toString() {
        return "{" + hours + ":" + minute + ":" + second + '}';
    }

}
