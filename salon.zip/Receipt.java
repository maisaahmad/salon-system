/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 * this class is used to create the receipt for the customer 
 */

import java.time.LocalTime;
import java.time.LocalDate;
public class Receipt  {
   /**
    * these attributes is used to show the customer the details of her receipt
    */
    private double fullPrice;
    private Time time;
    private Date date;
    /**
     *this  constructors is used to initial the value of local the time and date
     */
    public Receipt(){
        LocalTime t=LocalTime.now();
        int hour=t.getHour();
        int minute=t.getMinute();
        int second=t.getSecond();
        time=new Time(hour,minute,second);
        LocalDate d=LocalDate.now();
        int day=d.getDayOfMonth();
        int month=d.getMonthValue();
        int year=d.getYear();
        date=new Date(day,month,year);
    }
    /**
     * this  constructors is used to hold the value of local the time and date + fullPrice
     * @param fullPrice 
     */
    public Receipt(double fullPrice){
        this();
        this.fullPrice=fullPrice;
    }
    /**
    * this method for setting the full Price.
    * @param fullPrice 
    */
    public void setFullPrice(double fullPrice) {
        this.fullPrice = fullPrice;
    }
    /**
   * this method is use to return the full Price
   * @return double
   */ 
    public double getFullPrice() {
        return fullPrice;
    }
    /**
     * this method is used to add discount to the full price
     * @param percentage
     */
    public void addDiscount(double percentage){
        this.fullPrice=percentage/100*fullPrice;
    }
    
    /**
  * this method is used to display the RECEIPT
  * @return String
  */
    @Override
    public String toString() {
        return "SALON SERVICES RECEIPT\nPURCHASE AMOUNT: "+fullPrice+"\nThis receipt was issued in:\n"+date+"\t"+time;
    }
}