/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 * this interface with one method that use to calculate price for each service  
 */
public interface BookingManagement {
    
    public void calculatePrice();
}