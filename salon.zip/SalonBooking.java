/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.salonbooking;

/**
 * in the main we display our services to the user and the modifications on her reservation that she want  
 * @author huawei
 */
/**
 * we import the class util because we will use scanner and array list
 */
import java.util.*;
public class SalonBooking {
public static void main(String[] args) {
        /**
         * here we make a scanner object so we can use it 
         */
        Scanner in = new Scanner(System.in);
        /**
         * here we create array list for the booking
         */
        ArrayList<Booking> allBooking = new ArrayList<>();
        /**
         * here we create objects of class stylist to allow the user to pick one
         */
        Stylist stylistCnD = new Stylist("Ameera", "0508245322", "h8393", new Hair());
        Stylist stylistS = new Stylist("Amal", "0508250329", "h8093", new Hair());
        Stylist stylistN = new Stylist("Nora", "0558355249", "h8003", new Hair());

        Stylist stylistSp = new Stylist("Fatima", "0589440729", "f1234", new Face());
        Stylist stylistNo = new Stylist("Jana", "0527232320", "f74862", new Face());
        Stylist stylistB = new Stylist("Tala", "0527534890", "f0862", new Face());

        Stylist stylistNor = new Stylist("Lamis", "0508670329", "n8083", new Nails());
        Stylist stylistSpe = new Stylist("Sara", "0508250423", "n8693", new Nails());
        /**
         * here we create objects of services class to use it later 
         * we use polymorphism with class face and hair and nails
         * later we might cast them to use the subclass methods
         */
        Service face= new Face();
        Service hair = new Hair();
        Service nails=new Nails();
        /**
         * here we create object of customer to use it later in the cases 
         */
        Customer customer ;
        /**
        * here we create integer number for the customer choice of salon services
        */
        int choice = 0;
        while (choice <= 2) {
            System.out.println("Welocme to Beauty Salon!!\n"
                    + "To start, please press the number of the operation you want to perform:\n"
                    + "(1) Make a reservation\n"
                    + "(2) Display a reservation");
            choice = in.nextInt();//we change value of choice to the user's input
            switch (choice) {
                case 1:
                    /**
                     * We ask the user to input all his data,
                     * then we pass them to the customer object we declared previously
                     */
                    System.out.println("Please enter your info:");
                    System.out.println("Full name:");
                    in.nextLine();//to get rid of \n in prevoius input
                    String name = in.nextLine();
                    
                    System.out.println("Phone number: *kindly, make sure it is 10 numbers :)*");
                    String phone = in.next();
                    /**
                     * to avoid the error that may happen here
                     */
                    while(phone.length()!=10){
                        System.err.println("Invalid Phone Number! Try again!");
                        phone = in.next();
                    }
                    
                    System.out.println("CreditCard number: *kindly, make sure it is all integer, and 16 numbers :)*");
                    String ccNo = in.next();
                    /**
                     * to avoid the error that may happen here
                     */
                    while(ccNo.length()!=16){
                        System.err.println("Invalid Credit Card number! Try again!");
                        ccNo = in.next();
                    }
                    customer = new Customer(name, phone,ccNo);
                    
                    /**
                     * here we ask the user to enter the date of her reservation
                     * and check if she put valid input
                     */
                    System.out.println("Enter the day, month and year, respectively: (kindly, leave a space between each of them)");
                    int day = in.nextInt();
                    int month = in.nextInt();
                    int year = in.nextInt();
                    Date date = new Date(day, month, year);
                    while(date.check()==false){
                        day = in.nextInt();
                        month = in.nextInt();
                        year = in.nextInt();
                        date = new Date(day, month, year);
                    }
                    /**
                     * here we ask the user to enter the time of her reservation
                     * and check if she put valid input
                     */
                    System.out.println("Enter the hour(in 24 system) and minutes, respectively: (kindly, leave a space between the hour and minutes)"
                    +"\nNote: Our opening hours are from 10 to 22");
                    int hour = in.nextInt();
                    int minute = in.nextInt();
                    Time time = new Time(hour, minute);
                    while(time.check()==false){
                        hour = in.nextInt();
                        minute = in.nextInt();
                        time = new Time(hour, minute);
                    }
                    /**
                     * here we check if there is any 2 reservation at the same
                     * time and date
                     */
                    for (int i=0; i<allBooking.size(); i++) {
                        if (allBooking.get(i).checkAvailability(date, time)) {
                            System.out.println("The time you picked is available :)!");
                        } else {
                            System.err.println("Sorry! The time you picked is not available!");
                        }
                    }
                    
                    /**
                     * inner switch and inner loop for choosing services
                     */
                    int ser = 0;
                    while (ser <= 8) {
                        System.out.println("Choose the type of service you want:\n"
                                + "(1) Hair service\n"
                                + "(2) Face service\n"
                                + "(3) Nails service\n");
                        ser = in.nextInt();
                        switch (ser) {
                            /**
                             * case 1: if the user chooses hair service
                             * we print all hairstylists with services and prices so the user can choose
                             * then we ask about the hair length
                             */
                            case 1:
                                System.out.println("Choose the stylist: (just type the name of the stylist you want)\n"
                                        + "Ameera: haircuts & color specialist, prices range from 430SAR to 470SAR\n"
                                        + "Amal: special hair styling (weddings and important events), prices range from 280SAR to 320SAR\n"
                                        + "Nora: normal hair styling (daily styles and small parties), prices range from 180SAR to 220SAR");
                                String name1 = in.next();

                                System.out.println("Which one of these describes your hair length best?\n"
                                        + "(1) Short hair\n"
                                        + "(2) Mid-length hair\n"
                                        + "(3) Long hair");
                                int l = in.nextInt();

                                if (stylistCnD.getName().equalsIgnoreCase(name1)) {
                                    hair = new Hair(date, time, stylistCnD, 3, l);
                                    ((Hair) hair).setStyle(3);
                                    hair.calculatePrice();
                                    System.out.println("The price for this service is: "+hair.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistCnD);
                                    allBooking.add(new Booking(customer, stylistCnD, date, time));
                                    
                                } else if (stylistS.getName().equalsIgnoreCase(name1)) {
                                    hair = new Hair(date, time, stylistS, 1, l);
                                    ((Hair) hair).setStyle(1);
                                    hair.calculatePrice();
                                    System.out.println("The price for this service is: "+hair.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistS);
                                    allBooking.add(new Booking(customer, stylistS, date, time));
                                    
                                } else {
                                    hair = new Hair(date, time, stylistN, 2, l);
                                    ((Hair) hair).setStyle(2);
                                    hair.calculatePrice();
                                    System.out.println("The price for this service is: "+hair.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistN);
                                    allBooking.add(new Booking(customer, stylistN, date, time));
                                }
                                
                                System.out.println("Are there any more services you want? (please answer with yes or no only)");
                                String yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ser=9;
                                }
                                break;
                                //end of case 1 in inner switch
                            case 2:
                                System.out.println("Choose the stylist: (just type the name of the stylist you want)\n" +
                                         " Tala: bride makeup, prices range from 300SAR to 350SAR\n" +
                                         " Fatima: special makeup, prices range from 200SAR to 250SAR\n" +
                                        " Jana: normal makeup, prices range from 150SAR to 200SAR");
                                name1 = in.next();

                                System.out.println("What color of makeup do you want to wear? (if you haven't decided yet just write 'none')");
                                in.nextLine();//to get rid of \n in prevoius input
                                String color = in.nextLine();
                                
                                System.out.println("Do you need a skincare service as well? note that it will cost more (please answer with yes or no only)");
                                yon = in.next();
                                boolean p;
                                if (yon.equalsIgnoreCase("yes")) {
                                    p=true;
                                }else{
                                    p=false;
                                }

                                if (stylistB.getName().equalsIgnoreCase(name1)) {
                                    face = new Face(date, time, stylistB, 3, color);
                                    ((Face) face).setMakeupType(3);
                                    ((Face) face).setSkinCare(p);
                                    face.calculatePrice();
                                    System.out.println("The price for this service is: "+face.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistB);
                                    allBooking.add(new Booking(customer, stylistB, date, time));
                                    
                                } else if (stylistSp.getName().equalsIgnoreCase(name1)) {
                                    face = new Face(date, time, stylistSp, 1, color);
                                    ((Face) face).setMakeupType(1);
                                    ((Face) face).setSkinCare(p);
                                    face.calculatePrice();
                                    System.out.println("The price for this service is: "+face.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistSp);
                                    allBooking.add(new Booking(customer, stylistSp, date, time));
                                   
                                } else {
                                    face = new Face(date, time, stylistNo, 2, color);
                                    ((Face) face).setMakeupType(2);
                                    ((Face) face).setSkinCare(p);
                                    face.calculatePrice();
                                    System.out.println("The price for this service is: "+face.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistNo);
                                    allBooking.add(new Booking(customer, stylistNo, date, time));
                                }

                                System.out.println("Are there any more services you want? (please answer with yes or no only)");
                                yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ser=9;
                                }
                                break;
                                //end of case 2 in inner switch
                            case 3:
                                System.out.println("Choose the stylist: (type the name of the stylist you want)\n" +
                                     "Sara: manicure & pedicure, price is 70SAR\n" +
                                      "Lamis: manicure only, price is 20SAR");
                                name1 = in.next();

                                System.out.println("What color of nail polish do you want? (if you haven't decided yet just write 'none')");
                                in.nextLine();//to get rid of \n in prevoius input
                                color = in.nextLine();

                                System.out.println("What is shape that you want? (if you haven't decided yet just write 'none')");
                                String shape = in.nextLine();

                                if (stylistSpe.getName().equalsIgnoreCase(name1)) {
                                    nails = new Nails(date, time, stylistSpe, shape, color);
                                    ((Nails)nails).setPedicure(true);
                                    ((Nails) nails).calculatePrice();
                                    System.out.println("The price for this service is: "+nails.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistSpe);
                                    allBooking.add(new Booking(customer, stylistSpe, date, time));
                                    
                                } else {
                                    nails = new Nails(date, time, stylistNor, shape, color);
                                    ((Nails)nails).setPedicure(false);
                                    ((Nails) nails).calculatePrice();
                                    System.out.println("The price for this service is: "+nails.getPrice());
                                    System.out.println("Your stylist's info:\n" + stylistNor);
                                    allBooking.add(new Booking(customer, stylistNor, date, time));
                                }

                                System.out.println("Are there any more services you want? (please answer with yes or no only)");
                                yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ser=9;
                                }
                                break;
                                //end of case 3 in inner switch
                            default:
                                System.err.println("Invalid input! There is no case with this character!");
                        }
                        allBooking.get(allBooking.size()-1).addService(hair);
                        allBooking.get(allBooking.size()-1).addService(face);
                        allBooking.get(allBooking.size()-1).addService(nails);
                    }
                    break;
                    //end of inner while
                    
                /**
                 * case 2 of outer switch: for all the operation that require an already existing reservation
                 * we ask for the user's phone number first
                 * we used a for loop to check if that phone number exists in our system
                 */
                case 2:
                    System.out.println("Please write your phone number:");
                    in.nextLine();//to get rid of \n in prevoius input
                    phone = in.nextLine();
                    Booking  b=new Booking();
                    
                    for (int i = 0; i < allBooking.size(); i++) {
                        if (allBooking.get(i).getCustomer().getPhoneNumber().equals(phone)) {
                            b=allBooking.get(i);
                        }else{
                            System.err.println("Sorry! The phone number you entered is not in our system :(");
                            System.exit(0);
                        }
                    }
                    System.out.println(b);
                    /**
                     * inner switch in case 2 for letting the user choose a new operation
                     */
                    int ch=0;
                    while(ch<=4){
                    System.out.println("What else do you want to do with this reservation?\n" +
                        "(1) Update date and time\n" +
                        "(2) Delete reservation\n" +
                        "(3) Display my services and receipt\n" +
                        "(4) Leave a review\n" +
                        "(5) Nothing");
                        choice = in.nextInt();
                        switch (choice) {
                            /**
                             * case 1 in inner switch for updating time and date
                             */
                            case 1:
                                System.out.println("Enter the new day, month and year of your reservation, respectively: (kindly, leave a space between each of them)");
                                day = in.nextInt();
                                month = in.nextInt();
                                year = in.nextInt();
                                Date d1 = new Date(day, month, year);
                                while(d1.check()==false){
                                    day = in.nextInt();
                                    month = in.nextInt();
                                    year = in.nextInt();
                                    d1 = new Date(day, month, year);
                                    
                                }


                                System.out.println("Enter the new hour(in 24 system) and minutes of your reservation, respectively: (kindly, leave a space between the hour and minutes)"
                                +"\nNote: Our opening hours are from 10 to 22");
                                hour = in.nextInt();
                                minute = in.nextInt();
                                Time t1 = new Time(hour, minute);
                                while(t1.check()==false){
                                    hour = in.nextInt();
                                    minute = in.nextInt();
                                    t1 = new Time(hour,minute);
                                }
                                
                                for (int j = 0; j < allBooking.size(); j++) {
                                    if (b.checkAvailability(d1, t1)) {
                                        b.updateDate(d1);
                                        b.updateTime(t1);
                                        System.out.println("your date reservation has been updated ");
                                    }else{
                                        System.err.println("Sorry! The time you picked is not available!");
                                    }
                                }
                                allBooking.add(b);
                                System.out.println("Are there any more operations you want to perform? (please answer with yes or no only)");
                                String yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ch=6;
                                    choice=3;
                                }
                                break;
                                //end of case 1 in inner switch
                            /**
                             * case 2 in inner switch for deleting reservation
                             */
                            case 2:
                                allBooking.remove(b);
                                System.out.println("Your reservation has been deleted");
                                System.out.println("Are there any more operations you want to perform? (please answer with yes or no only)");
                                yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ch=6;
                                    choice=3;
                                }
                                break;
                            /**
                             * case 3 in inner switch for displaying services and receipt
                             */    
                            case 3:
                                b.displayService();
                                System.out.println("Payed using Credit Card ending in: "+b.getCustomer().getCreditCardNo());
                                System.out.println("Are there any more operations you want to perform? (please answer with yes or no only)");
                                yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ch=6;
                                    choice=3;
                                }
                                break;
                            case 4:
                                System.out.println("Did you like our services? (kindly answer with yes or no only.)");
                                String e = in.next();
                                boolean evaluation = false;
                                if (e.equalsIgnoreCase("yes")) {
                                    evaluation = true;
                                    System.out.println("Thank you for your input.\nWe are glad you liked it here and we hope to see you again!");
                                } else {
                                    evaluation = false;
                                    System.out.println("Thank you for your input.\nWe are sorry you didn't like our services. Please leave a note to help us improve!");
                                }
                                System.out.println("If you have any notes please leave them here, if not just type 'No notes'");
                                in.nextLine();//to get rid of \n in prevoius input
                                String notes = in.nextLine();
                                Review r1 = new Review(evaluation, notes, b.getCustomer(), b.getStylist());
                                b.setReview(r1);
                                System.out.println("__________________");
                                System.out.println(r1);
                                System.out.println("__________________");
                                System.out.println("Are there any more operations you want to perform? (please answer with yes or no only)");
                                yon = in.next();
                                if (yon.equalsIgnoreCase("yes")) {
                                    continue;
                                }else{
                                    ch=6;
                                    choice=3;
                                }
                                break;
                            case 5:
                                ch=6;
                                choice=3;
                                break;
                            default:
                               System.err.println("Invalid input! There is no case with this character");
                            }
                        if(b==null) {
                            System.out.println("Sorry! The phone number you entered is not in our system :(");
                        }}

                   
            }
        }
        System.out.println("Your request have been processed.\nThank you for choosing Beauty Salon. Have a nice day!");
    }
}