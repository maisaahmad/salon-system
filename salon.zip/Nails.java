/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *this class is for nails services
 * @author huawei
 */
public class Nails extends Service {
   //attributes
    private String Shape,polishColor;
    private boolean pedicure;
    //constructors
    public Nails() {}
    public Nails(String shpe,String pc){
        this.polishColor= pc;
        this.Shape= shpe;
    }
    public Nails(Date date,Time time,Stylist stylist,String shpe,String pc){
        super(date,time,stylist);
        this.polishColor= pc;
        this.Shape= shpe;
    }
    //methods
    public boolean getPedicure() {
        return pedicure;
    }
    public void setPedicure(boolean pedicure) {
        this.pedicure = pedicure;
    }
    public String getShape() {
        return Shape;
    }
    public void setShape(String Shape) {
        this.Shape = Shape;
    }
    public String getPolishColor() {
        return polishColor;
    }
    public void setPolishColor(String polishColor) {
        this.polishColor = polishColor;
    }
    @Override
    public void calculatePrice() {
        super.setPrice(20);
        if(pedicure){
            super.setPrice(getPrice()+50);
        }else{
            super.setPrice(getPrice());
        }
    }
    @Override
    public String toString() {
        return "Nails Service\nShape: " + Shape + "\nPolish Color: " + polishColor+"\nPrice: "+getPrice();
    }
}