/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 * this class is used to create the Services for the customer
 * @author huawei
 */
public abstract class Service implements BookingManagement {
    /**this attributes are used to show the details of the customer's service
     * 
     */
    private double price;
    private Date date;
    private Time time;
   private Stylist stylist=new Stylist();
   //maisa add this one
   /**
    * we add this attribute to make the service to the customer
    */
   private Customer customer;
   
      /**
     * we create the constructor because we need the argument constructor 
     */    
    public Service(){}
     /**
     * we create the constructor because we need the argument constructors in the main
     * @param date
     * @param time
     */
    public Service(Date date,Time time){
        this.date=date;
        this.time=time;
    }
    public Service(Date date,Time time,Stylist stylist){
        this.date=date;
        this.time=time;
        this.stylist=stylist;
    }
   //maisa add this one
    public Service(double price, Date date, Time time, Customer customer) {
        this.price = price;
        this.date = date;
        this.time = time;
        this.customer = customer;
    }
    
/**
   * this method is use to return the Stylist
   * @return Stylist
   */   
    public Stylist getStylist() {
        return stylist;
    }
    /**
    * this method for setting the time. 
     * @param stylist
    */
    public void setStylist(Stylist stylist) {
        this.stylist = stylist;
    }
    /**
   * this method is use to return the Date
   * @return Date
   */ 
    public Date getDate() {
        return date;
    }
    /**
    * this method for setting the date. 
     * @param date
    */
    public void setDate(Date date) {
        this.date = date;
    }
     /**
   * this method is use to return the Time
   * @return Time
   */ 
    public Time getTime() {
        return time;
    }
    /**
    * this method for setting the time. 
     * @param time
    */
    public void setTime(Time time) {
        this.time = time;
    }
     /**
   * this method is use to return the price
   * @return double
   */ 
    public double getPrice(){
        return price;
    }
    /**
    * this method for setting the price. 
     * @param price
    */
    public void setPrice(double price){
        this.price=price;
    }
     /**
   * this method is use to return the Customer
   * @return Customer
   */ 
    public Customer getCustomer() {
        return customer;
    }
    /**
    * this method for setting the customer. 
     * @param customer
    */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    /**
     * this method is used to override it in each type services to calculate Price by the service that customer want
     */
    @Override
    public abstract void calculatePrice();
    /**
     * this method is used to display the attributes of the class as string
     * @return 
     */
    @Override
    public String toString() {
        return "Service:\nStylist: " + stylist +"\nPrice: "+getPrice();
    }
    @Override
    public boolean equals(Object obj) {
        Service s=(Service)obj;
        if (s.date.equals(this.date)&&s.time.equals(this.time)&&s.stylist.equals(this.stylist)){
            return true;
        } else {
            return false;
        }
    }
}