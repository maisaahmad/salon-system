/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 * this class is for hair services
 * @author huawei
 */
public class Hair extends Service{
//attributes
    private int length,style;
    //constructors
    public Hair(){}
  //for case 2 in the main
    public Hair( Date date, Time time, Stylist stylist,int style) {
        super(date, time, stylist);
        this.style = style;
    }
    
    public Hair(Date date,Time time,Stylist stylist,int style,int length){
        super(date,time,stylist);
        this.style=style;
        this.length=length;
    }
    //setter & getters
    public int getStyle() {
        return style;
    }
    public void setStyle(int style) {
        switch(style){
            case 1://special hairstyle
                super.setPrice(250);
                break;
            case 2://normal hairstyle
                super.setPrice(150);
                break;
            case 3://cut and dye
                super.setPrice(400);
                break;
            default://neither
                System.out.println("Invalid input");
        }
    }
    public int getLength() {
          
            return length;
    }
    public void setLength(int length) {
        this.length = length;
    }
    @Override
    public String toString() {
        String l=new String();
        if(length==1)
            l="short";
        else if(length==2)
            l="mid-length";
        else
            l="long";
        String s=new String();
        if (style==1)
            s="Special";
        else if (style==2)
            s="Normal";
        else
            s="Haircut/Hairdye";
        return "Hair Service\nStyle: " + s+ "\nLength: " + l+"\nprice: "+getPrice();
    }
    @Override
    public void calculatePrice() {
        switch(length){
            case 1://short
                super.setPrice(getPrice()+30);
                break;
            case 2://mid-length
                super.setPrice(getPrice()+50);
                break;
            case 3://long
                super.setPrice(getPrice()+70);
                break;
            default://neither
                System.out.println("Invalid input");
        }
    }
}