/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salonbooking;

/**
 *
 * @author huawei
 */
public class Date {
    /**
     * these attributes for reservation Date and local Date of receipt
    */
    private int year;
    private int month;
    private int day;
    
    /**
     * we create the constructor because we need the argument constructor 
     */
    public Date(){
      year=day=month=0; 
    }
    /**
     * we create this constructor to hold the value in  object for  reservation Date.we add this condition to make sure the user i/p the correct date
     * @param day
     * @param month
     * @param year
     */
    public Date(int day,int month,int year){
    if(year>=2023&&month<=12&&month>=1&&day<=31&&day>=1){
    this.day=day;
    this.month=month;
    this.year=year;}
    else{
        System.err.println("the date you enter is not correct! try again");
    }
    
    }
    /**
   * this method is use to return the year
   * @return int
   */
    public int getYear() {
        return year;
    }
     /**
    * this method for setting the year.
    * we add this condition to make sure the user i/p the correct year
    * @param year 
    */
    public void setYear(int year) {
        if(year>=2023){
        this.year = year; }
    }
    /**
   * this method is use to return the month
   * @return int
   */
    public int getMonth() {
        return month;
    }
   /**
    * this method for setting the month.
    * we add this condition to make sure the user i/p the correct month
    * @param month 
    */
    public void setMonth(int month) {
        if(month<=12&&month>=1){
        this.month = month;}
    }
   /**
   * this method is use to return the month
   * @return int
   */
    public int getDay() {
        return day;
    }
      /**
    * this method for setting the day.
    * we add this condition to make sure the user i/p the correct days
    * @param day 
    */
    public void setDay(int day) {
        if(day<=31&&day>=1)
        this.day = day;
    }
    /**
     * we used this method to check if our conditions on date were applied 
     * we used it in the main class as a loop condition to let user try again
     */
    public boolean check(){
        if(year>=2023&&month<=12&&month>=1&&day<=31&&day>=1){
            return true;}
        else{
            return false;}
        }
    
    /**
     * this method is used to display the date
      * @return String
     *  
     */
   @Override
    public String toString(){
        return day+"/"+month+"/"+year ;
    }
     /**
  * this method is used for (checkAvailability) method in class booking
  * @param obj
  * @return boolean 
  */
     @Override
    public boolean equals(Object obj){
        Date d=(Date)obj;
        if (d.day==this.day && d.month==this.month && d.year==this.year)
            return true;
        else
            return false;
    }
}